package com.sopt.semina_06.post

data class postWriteBoardResponse(
    val status : String,
    val message : String
)

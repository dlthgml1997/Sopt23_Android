package com.sopt.semina_06.post

data class PostSignUpResponse(
    val status : String,
    val message : String
)